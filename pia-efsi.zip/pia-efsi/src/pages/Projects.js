import React from 'react'
import { useContext } from 'react'
import { ProjectContext } from '../context/ProjectContext';
import { Link } from 'react-router-dom';

import Project from '../components/Project';

function Projects() {
    const { projectsList, addProject } = useContext(ProjectContext);

    return (
        <>
            <h1> Projects </h1>
            {projectsList.map((project, index) => (
                <Project id={index} nombre={project.Nombre}></Project>
            ))
}
        </>
    )
}

export default Projects