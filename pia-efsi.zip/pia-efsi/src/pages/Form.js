import React from 'react'
import { useState, useContext } from 'react';
import { ProjectContext } from '../context/ProjectContext';

function Form() {
  const { projectsList, addProject } = useContext(ProjectContext);

  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [tecnologias, setTecnologias] = useState('');

  function addProjectToContext(){
    const project = {
      'Nombre': nombre,
      "Descripcion": descripcion,
      'Tecnologias': tecnologias,
      'Tareas': null,
    }

    addProject(project)
  }

  return (
    <>
     <form onSubmit={() => addProjectToContext()}>
      <h1>Crear proyecto</h1>

      <div className="">
        <label>Nombre:</label>
        <input type="text" name="nombre" id="nombre" required onChange={(e) => setNombre(e.target.value)} />
      </div>

      <div className="">
        <label>Descripción:</label>
        <textarea name="descripcion" id="descripcion" rows="5" cols="50" required onChange={(e) => setDescripcion(e.target.value)}></textarea>
      </div>

      <div className="">
        <label>Tecnologías:</label>
        <input type="text" name="tecnologias" id="tecnologias" required onChange={(e) => setTecnologias(e.target.value)}/>
      </div>

      <button type="submit">Crear</button>
      </form>
    </>
  )
}

export default Form