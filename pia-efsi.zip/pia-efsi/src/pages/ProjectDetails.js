import React, { useState } from 'react'
import { useContext } from 'react'
import { useParams } from 'react-router-dom';
import { ProjectContext } from '../context/ProjectContext';

function Projects() {
    const { projectsList, addProject, addTarea } = useContext(ProjectContext);
    const { id } = useParams();
    const obj = projectsList[id]
    const [tareaAgregar, setTareaAgregar] = useState();

    function agregarTarea() {
        var tareaAux = {
            'Contenido': tareaAgregar,
            'Checked': false,
        }
        obj.Tareas != null ? obj.Tareas.push(tareaAux) : obj.Tareas = [tareaAux];
        addTarea(obj)
    }

    function checkTarea(index) {
        obj.Tareas[index.target.value].Checked = true;
        addTarea(obj)
    }

    return (
        <>
            <h1> {obj.Nombre} </h1>
            <p> {obj.Descripcion} </p>
            <p> {obj.Tecnologias} </p>

            <h3> Tareas: </h3>
            <p>{obj.Tareas != null ? obj.Tareas.map((tarea, index) => (
                <>
                    <p> {tarea.Contenido} </p>
                    {tarea.Checked === true ?
                        <input type="checkbox" name="tarea" checked value={index} />
                        :
                        <input type="checkbox" name="tarea" value={index} onClick={(e) => checkTarea(e)} />
                    }

                </>
            )) : 'no hay tareas'} </p>

            <br></br>
            <form onSubmit={() => agregarTarea()}>

                <div className="">
                    <label>Descripción:</label>
                    <textarea name="descripcion" id="descripcion" rows="5" cols="50" required onChange={(e) => setTareaAgregar(e.target.value)}></textarea>
                </div>

                <button type="submit">Agregar Tarea</button>
            </form>
        </>
    )
}

export default Projects