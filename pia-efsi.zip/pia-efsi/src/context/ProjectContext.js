import React from 'react';
import { useState, useContext, useEffect } from 'react';
import { createContext } from 'react';

export const ProjectContext = createContext();

export const ProjectProvider = (props) => {
    let inicial = localStorage.getItem('projectsList') ? JSON.parse(localStorage.getItem('projectsList')) : [];
    const [projectsList, setProjectsList] = useState(inicial);

    function addProject(project) {
        setProjectsList([...projectsList, project])
    }

    function addTarea(projectConTarea) {
        var temp = projectsList
        temp.map((project, index) => {
            if (project.Nombre === projectConTarea.Nombre) {
                temp[index] = projectConTarea
            }
        })

        setProjectsList(temp)
        localStorage.setItem('projectsList', JSON.stringify(temp))
    }

    useEffect(() => {
        localStorage.setItem('projectsList', JSON.stringify(projectsList))
    }, [projectsList])

    return (
        <ProjectContext.Provider value={{ projectsList, addProject, addTarea }}>
            {props.children}
        </ProjectContext.Provider>
    )
}


export default ProjectProvider;