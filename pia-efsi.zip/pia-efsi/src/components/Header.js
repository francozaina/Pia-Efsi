import React from 'react'
import PropTypes from 'prop-types'
import { Link } from "react-router-dom";

function Header(props) {
    return (
        <div className="header">
            <div className="container">
                <div className="navbar">
                    <nav>
                        <ul id="MenuItems">
                            <li><Link to="/form">Formulario</Link></li>
                            <li><Link to="/projects">Proyectos</Link></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    )
}

Header.propTypes = {}

export default Header