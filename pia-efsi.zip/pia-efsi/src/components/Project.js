import React from 'react'
import { Link } from "react-router-dom";


export default function Project({ id, nombre }) {
    const link = "/project_details/" + id;
    return (
        <>
            <div className="col-4">
                <Link to={link}><h4>{nombre}</h4></Link>
            </div>
        </>
    )
}