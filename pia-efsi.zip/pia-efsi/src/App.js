import logo from './logo.svg';
import './App.css';

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Form from './pages/Form.js'
import Projects from './pages/Projects.js'
import Header from './components/Header.js'
import ProjectDetails from './pages/ProjectDetails.js'

import ProjectProvider from './context/ProjectContext.js';

function App() {
  return (
    <ProjectProvider>
      <Router>
        <Header />
        <Routes>
          <Route path="/" element={<Projects />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/form" element={<Form />} />
          <Route path="/project_details/:id" element={<ProjectDetails />} />
        </Routes>
      </Router>
    </ProjectProvider>
  );
}

export default App;
